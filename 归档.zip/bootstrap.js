const { Bootstrap } = require('@midwayjs/bootstrap');
require('dotenv').config();
Bootstrap.run();
